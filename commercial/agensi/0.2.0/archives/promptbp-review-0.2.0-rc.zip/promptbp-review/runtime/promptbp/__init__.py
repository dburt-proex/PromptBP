"""PromptBP prompt structure validation."""
